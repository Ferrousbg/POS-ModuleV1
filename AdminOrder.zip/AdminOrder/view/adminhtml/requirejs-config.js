var config = {
    map: {
        '*': {
            'Alpine': 'https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js',
            'Ferrousbg_AdminOrder/js/pos/core': 'Ferrousbg_AdminOrder/js/pos/core',
            'Ferrousbg_AdminOrder/js/pos/customer': 'Ferrousbg_AdminOrder/js/pos/customer',
            'Ferrousbg_AdminOrder/js/pos/cart': 'Ferrousbg_AdminOrder/js/pos/cart',
            'Ferrousbg_AdminOrder/js/pos/shipping': 'Ferrousbg_AdminOrder/js/pos/shipping',
            'Ferrousbg_AdminOrder/js/pos/products': 'Ferrousbg_AdminOrder/js/pos/products',
            'Ferrousbg_AdminOrder/js/pos/store': 'Ferrousbg_AdminOrder/js/pos/store'
        }
    }
};